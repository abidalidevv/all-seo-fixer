import re

def clean_brand_name(site_title, home_url='https://efix.ae'):
    site_title = (site_title or '').strip()
    if not site_title or site_title.lower() == 'wordpress':
        host = home_url.replace('https://', '').replace('http://', '').split('/')[0]
        brand = re.sub(r'^www\.', '', host, flags=re.I)
        brand = re.sub(r'\.[a-z]{2,6}$', '', brand, flags=re.I)
        return brand.capitalize()
    
    # Split by delimiters |, —, –, -, :, •
    for delim in ['|', '—', '–', '-', ':', '•']:
        if delim in site_title:
            site_title = site_title.split(delim)[0].strip()
            break
            
    # Check if domain matches prefix (e.g. efix in "eFix Electronics Repair")
    host = home_url.replace('https://', '').replace('http://', '').split('/')[0]
    short_host = re.sub(r'^www\.', '', host, flags=re.I)
    short_host = re.sub(r'\.[a-z]{2,6}$', '', short_host, flags=re.I)
    
    if short_host.lower() in site_title.lower() and len(site_title) > 12:
        words = site_title.split()
        if words[0].lower() == short_host.lower():
            return words[0]
            
    if len(site_title) > 12:
        site_title = site_title.split()[0]
    return site_title[:12] if site_title else 'eFix'

def generate_smart_title(p_title, post_type='page', brand='eFix'):
    title = p_title.strip()
    # Strip redundant brand or site prefixes/suffixes if existing
    title = re.sub(r'\s*([|\-–—:]\s*(eFix|Official Site|WordPress|Electronics Repair)).*$', '', title, flags=re.I).strip()
    title = re.sub(r'^Apple\s+(MacBook|iMac|iPhone|iPad)', r'\1', title, flags=re.I).strip()
    
    lower = title.lower()
    brand_suf = f" | {brand}"
    
    # Custom high-intent title rules strictly 48 - 60 chars
    # Phones
    if 'iphone' in lower:
        # e.g. iPhone 8 Repair -> iPhone 8 Screen & Battery Replacement | eFix (50)
        cand = f"{title} Screen & Battery Fix in Dubai{brand_suf}"
        if 48 <= len(cand) <= 60: return cand
        cand = f"{title} Screen & Battery Replacement{brand_suf}"
        if 48 <= len(cand) <= 60: return cand
        cand = f"{title} - Same Day Screen Repair{brand_suf}"
        if 48 <= len(cand) <= 60: return cand
        return f"{title} Screen & Hardware Repair{brand_suf}"[:60]
        
    if 'samsung' in lower or 'galaxy' in lower:
        cand = f"{title} Screen & Glass Repair | {brand} UAE"
        if 48 <= len(cand) <= 60: return cand
        cand = f"{title} Screen & Battery Replacement{brand_suf}"
        if 48 <= len(cand) <= 60: return cand
        cand = f"{title} - Fast Repair in Dubai{brand_suf}"
        if 48 <= len(cand) <= 60: return cand
        return f"{title} Screen & Battery Fix{brand_suf}"[:60]

    # Laptops & Mac
    if any(k in lower for k in ['laptop', 'macbook', 'imac', 'surface']):
        cand = f"{title} & Screen Fix in Dubai{brand_suf}"
        if 48 <= len(cand) <= 60: return cand
        cand = f"{title} & Motherboard Repair{brand_suf}"
        if 48 <= len(cand) <= 60: return cand
        cand = f"{title} & Screen Replacement{brand_suf}"
        if 48 <= len(cand) <= 60: return cand
        cand = f"{title} - Fast Hardware Fix in UAE{brand_suf}"
        if 48 <= len(cand) <= 60: return cand
        return f"{title} & Diagnostics Service{brand_suf}"[:60]

    # Tablets
    if 'tablet' in lower or 'ipad' in lower:
        cand = f"{title} Screen & Battery Fix in Dubai{brand_suf}"
        if 48 <= len(cand) <= 60: return cand
        cand = f"{title} Screen & Glass Replacement{brand_suf}"
        if 48 <= len(cand) <= 60: return cand
        cand = f"{title} - Fast Certified Repairs{brand_suf}"
        if 48 <= len(cand) <= 60: return cand
        return f"{title} & Hardware Fix | {brand} UAE"[:60]
        
    # Services
    if 'service' in lower:
        cand = f"Electronics & Device Repair Services in Dubai | {brand}"
        if 48 <= len(cand) <= 60: return cand
        return f"Expert Device Repair Services in UAE{brand_suf}"

    # General fallback
    cand = f"{title} - Fast Certified Service in Dubai{brand_suf}"
    if 48 <= len(cand) <= 60: return cand
    cand2 = f"{title} Repair & Diagnostics in UAE{brand_suf}"
    if 48 <= len(cand2) <= 60: return cand2
    return f"{title} | {brand} Dubai"

def generate_smart_meta(p_title, post_type='page', brand='eFix'):
    title = p_title.strip()
    title = re.sub(r'\s*([|\-–—:]\s*(eFix|Official Site|WordPress|Electronics Repair)).*$', '', title, flags=re.I).strip()
    
    meta = f"Need professional {title}? {brand} provides same-day diagnostics, genuine parts, and warranty-backed repair in Dubai & Sharjah. Book online today!"
    if len(meta) > 155:
        meta = f"Expert {title} at {brand}. Same-day diagnostics, genuine parts, and certified warranty repairs in Dubai & Sharjah. Contact our team today!"
    if len(meta) > 155:
        meta = f"Professional {title} by certified {brand} technicians. Genuine parts, quick turnaround, and full warranty in UAE. Contact us now!"
    if len(meta) < 120:
        meta = meta.rstrip('.') + " Call or visit our service center today!"
    return meta

pages = [
    "Acer Laptop Repair",
    "Asus Laptop Repair",
    "Microsoft Surface Pro Repair",
    "Apple iMac Repair",
    "Apple Macbook Pro Repair",
    "Apple Macbook Air Repair",
    "Other Tablet Repair",
    "Android Tablet Repair",
    "Asus Tablet Repair",
    "Acer Tablet Repair",
    "Lenovo Tablet Repair",
    "Other Samsung Device Repair",
    "Samsung A Series Repair",
    "Samsung J Series Repair",
    "Samsung Note Series Repair",
    "Samsung Note 8 Repair",
    "Samsung Note 9 Repair",
    "Samsung S10 Repair",
    "Samsung S10 Plus Repair",
    "Samsung Galaxy Note 10 Repair",
    "Samsung Galaxy S20 Repair",
    "Samsung Galaxy Note 20 Repair",
    "iPhone 8 Repair",
    "iPhone X Repair"
]

print("="*90)
print(f"{'PAGE TITLE':<30} | {'T_LEN':<5} | {'M_LEN':<5} | GENERATED TITLE")
print("="*90)
for p in pages:
    t = generate_smart_title(p)
    m = generate_smart_meta(p)
    print(f"{p:<30} | {len(t):<5} | {len(m):<5} | {t}")
    assert 48 <= len(t) <= 60, f"Title length {len(t)} not in 48-60 for {p}"
    assert 120 <= len(m) <= 155, f"Meta length {len(m)} not in 120-155 for {p}"
    assert "..." not in t, f"Ellipsis in title for {p}"
print("="*90)
print("ALL 24 PAGES PASSED STRICT 48-60 CHAR AND 120-155 CHAR RULES WITH ZERO ELLIPSIS!")
