import re

def generate_smart_seo_title(raw_title, brand="eFix", location="Dubai & Sharjah"):
    # Strip existing brand suffix if already present
    clean_title = re.sub(r'\s*([|\-–—:]\s*(eFix|Official Site|WordPress)).*$', '', raw_title, flags=re.I).strip()
    
    # Clean redundant "Apple " prefix if Macbook/iMac
    clean_title = re.sub(r'^Apple\s+(Macbook|iMac|iPhone|iPad)', r'\1', clean_title, flags=re.I).strip()
    
    brand_suffix = f" | {brand}" # e.g. " | eFix" (7 chars)
    
    lower = clean_title.lower()
    
    # 1. Phone Repair Pages (iPhone, Samsung, etc.)
    if any(k in lower for k in ['iphone', 'samsung', 'huawei', 'xiaomi', 'pixel', 'oneplus', 'galaxy']):
        # If specific model e.g. iPhone 8 Repair or Samsung S10 Repair
        cand1 = f"{clean_title} & Screen Replacement{brand_suffix}" # ~50-55 chars
        cand2 = f"{clean_title} & Battery Replacement{brand_suffix}"
        cand3 = f"{clean_title} in {location}{brand_suffix}"
        cand4 = f"{clean_title} - Same Day Screen Fix{brand_suffix}"
        
        # Pick based on length
        for cand in [cand1, cand2, cand3, cand4]:
            if 48 <= len(cand) <= 60:
                return cand
        if len(cand1) > 60:
            short_cand = f"{clean_title} Screen Fix | {brand} UAE"
            if 48 <= len(short_cand) <= 60:
                return short_cand
            return cand3[:60] if len(cand3) <= 60 else f"{clean_title} | {brand} UAE"
        return cand1
        
    # 2. Laptop & Computer Repair Pages
    if any(k in lower for k in ['laptop', 'macbook', 'imac', 'computer', 'desktop', 'surface']):
        cand1 = f"{clean_title} & Screen Fix in {location}{brand_suffix}"
        cand2 = f"{clean_title} & Logic Board Diagnostics{brand_suffix}"
        cand3 = f"{clean_title} & Screen Replacement{brand_suffix}"
        cand4 = f"{clean_title} - Fast Hardware Fix{brand_suffix}"
        for cand in [cand1, cand2, cand3, cand4]:
            if 48 <= len(cand) <= 60:
                return cand
        return cand3[:60] if len(cand3) <= 60 else f"{clean_title} | {brand} UAE"

    # 3. Tablet Repair Pages
    if 'tablet' in lower or 'ipad' in lower:
        cand1 = f"{clean_title} & Glass Replacement{brand_suffix}"
        cand2 = f"{clean_title} & Battery Fix in Dubai{brand_suffix}"
        cand3 = f"{clean_title} - Fast Certified Repairs{brand_suffix}"
        for cand in [cand1, cand2, cand3]:
            if 48 <= len(cand) <= 60:
                return cand
        return cand1[:60]
        
    # General Repair
    cand = f"{clean_title} - Certified Experts in UAE{brand_suffix}"
    if 48 <= len(cand) <= 60:
        return cand
    cand2 = f"{clean_title} & Diagnostics Service{brand_suffix}"
    if 48 <= len(cand2) <= 60:
        return cand2
        
    return f"{clean_title} | {brand} UAE"

pages = [
    "Acer Laptop Repair",
    "Asus Laptop Repair",
    "Microsoft Surface Pro Repair",
    "Apple iMac Repair",
    "Apple Macbook Pro Repair",
    "Apple Macbook Air Repair",
    "Other Tablet Repair",
    "Android Tablet Repair",
    "Asus Tablet Repair",
    "Acer Tablet Repair",
    "Lenovo Tablet Repair",
    "Other Samsung Device Repair",
    "Samsung A Series Repair",
    "Samsung J Series Repair",
    "Samsung Note Series Repair",
    "Samsung Note 8 Repair",
    "Samsung Note 9 Repair",
    "Samsung S10 Repair",
    "Samsung S10 Plus Repair",
    "Samsung Galaxy Note 10 Repair",
    "Samsung Galaxy S20 Repair",
    "Samsung Galaxy Note 20 Repair",
    "iPhone 8 Repair",
    "iPhone X Repair"
]

print(f"{'PAGE TITLE':<32} | {'CHARS':<5} | GENERATED SEO TITLE")
print("-" * 90)
for p in pages:
    t = generate_smart_seo_title(p)
    print(f"{p:<32} | {len(t):<5} | {t}")
