import re

def clean_brand_name(site_title, home_url='https://efix.ae'):
    site_title = (site_title or '').strip()
    
    # 1. First extract host domain brand
    host = home_url.replace('https://', '').replace('http://', '').split('/')[0]
    domain_brand = re.sub(r'^www\.', '', host, flags=re.I)
    domain_brand = re.sub(r'\.[a-z]{2,6}$', '', domain_brand, flags=re.I)
    
    if not site_title or site_title.lower() == 'wordpress':
        return domain_brand.capitalize()
    
    # 2. If site_title contains delimiters, take the first segment
    for delim in ['|', '—', '–', ' - ', ':', '•']:
        if delim in site_title:
            site_title = site_title.split(delim)[0].strip()
            break
            
    # 3. If site_title is long (>15 chars) and contains domain brand (case-insensitive)
    if len(site_title) > 15:
        # Check if first word or acronym matches domain brand
        words = site_title.split()
        if words and words[0].lower() == domain_brand.lower():
            return words[0]
        # Or if "Electronics Repair" or "Shop" or "Official Site" is appended
        cleaned = re.sub(r'\b(Electronics\s*Repair|Mobile\s*Phone|Repair\s*Center|Shop|Store|Official\s*Site)\b.*$', '', site_title, flags=re.I).strip()
        if cleaned and len(cleaned) <= 15:
            return cleaned
        if words:
            return words[0]
            
    return site_title if site_title else domain_brand.capitalize()

def generate_bulletproof_title(p_title, post_type='page', brand='eFix'):
    raw = p_title.strip()
    # Strip existing brand suffix if already present
    cleaned = re.sub(r'\s*([|\-–—:]\s*(eFix|Official Site|WordPress|Electronics Repair|Mobile Phone)).*$', '', raw, flags=re.I).strip()
    if not cleaned:
        cleaned = raw
        
    lower = cleaned.lower()
    brand_suf = f" | {brand}"
    
    # Check page type / intent
    # 1. Standard pages
    if lower == 'cart' or 'cart' in lower:
        return f"Your Shopping Cart & Secure Online Checkout | {brand} UAE"[:60]
    if lower == 'checkout' or 'checkout' in lower:
        return f"Secure Checkout & Fast Order Completion in UAE | {brand}"[:60]
    if lower in ['home', 'homepage']:
        return f"Expert Device & Electronics Repair in Dubai | {brand}"[:60]
    if 'contact' in lower:
        return f"Contact Us & Repair Service Center Location | {brand} UAE"[:60]
    if 'about' in lower:
        return f"About Us & Certified Technicians Team | {brand} UAE"[:60]
    if lower in ['services', 'service', 'our services']:
        return f"Certified Device Repair & Screen Services | {brand}"[:60]
        
    # 2. Repair / Device pages
    is_repair = 'repair' in lower or 'fix' in lower or post_type in ['page', 'service']
    
    # Target character budget: 48 - 60 chars
    # We will test candidate suffixes in priority order to hit 48 - 60 chars exactly!
    candidates = []
    
    # Specialized device patterns
    if 'iphone' in lower:
        candidates = [
            f"{cleaned} Screen & Battery Fix in Dubai{brand_suf}",
            f"{cleaned} Screen & Battery Replacement{brand_suf}",
            f"{cleaned} - Same Day Screen Repair in UAE{brand_suf}",
            f"{cleaned} - Fast Screen & Battery Fix | {brand} UAE",
            f"{cleaned} Screen & Glass Repair in Dubai | {brand}",
            f"{cleaned} - Expert Diagnostics & Fix{brand_suf}",
            f"{cleaned} Screen & Battery Repair | {brand} UAE",
            f"{cleaned} - Certified Screen Fix in Dubai | {brand}",
        ]
    elif any(k in lower for k in ['samsung', 'galaxy', 'note', 'a series', 'j series']):
        candidates = [
            f"{cleaned} Screen & Glass Repair | {brand} UAE",
            f"{cleaned} Screen & Battery Fix in Dubai{brand_suf}",
            f"{cleaned} Screen & Battery Replacement{brand_suf}",
            f"{cleaned} - Fast Screen & Glass Repair{brand_suf}",
            f"{cleaned} - Genuine Screen Replacement | {brand}",
            f"{cleaned} - Fast Repairs & Screen Fix{brand_suf}",
            f"{cleaned} Screen & Battery Fix | {brand} UAE",
            f"{cleaned} - Certified Mobile Repair | {brand}",
        ]
    elif any(k in lower for k in ['macbook', 'imac', 'laptop', 'surface', 'computer']):
        candidates = [
            f"{cleaned} & Screen Fix in Dubai | {brand}",
            f"{cleaned} & Screen Replacement in UAE | {brand}",
            f"{cleaned} - Fast Hardware Fix in Dubai | {brand}",
            f"{cleaned} - Screen & Battery Fix in Dubai | {brand}",
            f"{cleaned} & Motherboard Repair in Dubai | {brand}",
            f"{cleaned} - Fast Diagnostics & Repair | {brand}",
            f"{cleaned} & Hardware Repair Service | {brand} UAE",
            f"{cleaned} - Expert Screen & Battery Fix | {brand}",
        ]
    elif any(k in lower for k in ['tablet', 'ipad']):
        candidates = [
            f"{cleaned} Screen & Battery Fix in Dubai{brand_suf}",
            f"{cleaned} Screen & Battery Fix in Dubai | {brand} UAE",
            f"{cleaned} Screen & Glass Replacement{brand_suf}",
            f"{cleaned} Screen & Battery Replacement | {brand}",
            f"{cleaned} - Fast Certified Repair in Dubai | {brand}",
            f"{cleaned} & Hardware Fix | {brand} UAE",
            f"{cleaned} - Same Day Screen Fix in Dubai | {brand}",
            f"{cleaned} - Fast Screen & Glass Fix | {brand} UAE",
        ]
    elif is_repair:
        candidates = [
            f"{cleaned} - Fast Certified Service in Dubai{brand_suf}",
            f"{cleaned} & Diagnostics Service in UAE{brand_suf}",
            f"{cleaned} - Expert Same Day Fix in Dubai | {brand}",
            f"{cleaned} & Screen Replacement in Dubai | {brand}",
            f"{cleaned} - Professional Repair in UAE | {brand}",
            f"{cleaned} | Certified Fast Repair in Dubai",
        ]
    else:
        candidates = [
            f"{cleaned} - Buy Online with Warranty | {brand} UAE",
            f"Certified {cleaned} - Best Deals in UAE | {brand}",
            f"{cleaned} — Complete Overview & Specs | {brand} UAE",
            f"{cleaned} - Fast Delivery in UAE | {brand}",
            f"{cleaned} | Official Guide & Store | {brand}",
        ]
        
    # Check if any candidate hits 48 - 60 chars
    for cand in candidates:
        if 48 <= len(cand) <= 60:
            return cand
            
    # Generic length-padding / trimming fallback
    # If too short:
    pad_options = [
        f" in Dubai & Sharjah | {brand}",
        f" - Certified Service in Dubai | {brand}",
        f" - Fast Same Day Fix | {brand} UAE",
        f" Screen & Battery Fix | {brand} UAE",
        f" Repair & Fix in Dubai | {brand}",
        f" | {brand} Dubai Repair Center",
        f" | {brand} UAE",
        f" | {brand}",
    ]
    for pad in pad_options:
        cand = cleaned + pad
        if 48 <= len(cand) <= 60:
            return cand
            
    # If base cleaned + brand is too long (> 60 chars):
    if len(cleaned + brand_suf) > 60:
        max_base = 60 - len(brand_suf)
        truncated_base = cleaned[:max_base].rsplit(' ', 1)[0]
        return truncated_base + brand_suf
        
    cand = f"{cleaned}{brand_suf}"
    if len(cand) < 48:
        # Add " Repair in Dubai" or " Service in UAE"
        cand = f"{cleaned} Service in UAE{brand_suf}"
        if 48 <= len(cand) <= 60:
            return cand
        cand = f"{cleaned} Repair & Fix in Dubai | {brand}"
        if 48 <= len(cand) <= 60:
            return cand
            
    return cand[:60]

def generate_bulletproof_meta(p_title, post_type='page', brand='eFix'):
    raw = p_title.strip()
    cleaned = re.sub(r'\s*([|\-–—:]\s*(eFix|Official Site|WordPress|Electronics Repair|Mobile Phone)).*$', '', raw, flags=re.I).strip()
    if not cleaned: cleaned = raw
    
    cand1 = f"Need expert {cleaned}? {brand} provides fast same-day diagnostics, genuine parts, and warranty-backed repairs in Dubai & Sharjah. Contact us today!"
    if 120 <= len(cand1) <= 155:
        return cand1
        
    cand2 = f"Professional {cleaned} at {brand}. Certified technicians, genuine replacement parts, quick turnaround, and full warranty coverage across UAE. Call now!"
    if 120 <= len(cand2) <= 155:
        return cand2
        
    cand3 = f"Looking for trusted {cleaned}? {brand} offers certified repairs, original parts, and fast service in Dubai & Sharjah. Book your repair online today!"
    if 120 <= len(cand3) <= 155:
        return cand3
        
    cand4 = f"Get reliable {cleaned} with {brand} UAE. Certified service, genuine parts, fast diagnostics, and complete warranty. Visit our repair center today!"
    if 120 <= len(cand4) <= 155:
        return cand4
        
    if len(cand1) > 155:
        sub = cand1[:150].rsplit(' ', 1)[0].rstrip('.,:;-') + '. Book online today!'
        if len(sub) > 155:
            sub = cand1[:152].rsplit(' ', 1)[0].rstrip('.,:;-') + '.'
        return sub
        
    if len(cand1) < 120:
        return cand1.rstrip('.') + " Contact our expert technicians today!"
        
    return cand1

test_pages = [
    "Acer Laptop Repair",
    "Asus Laptop Repair",
    "Microsoft Surface Pro Repair",
    "Apple iMac Repair",
    "Apple Macbook Pro Repair",
    "Apple Macbook Air Repair",
    "Other Tablet Repair",
    "Android Tablet Repair",
    "Asus Tablet Repair",
    "Acer Tablet Repair",
    "Lenovo Tablet Repair",
    "Other Samsung Device Repair",
    "Samsung A Series Repair",
    "Samsung J Series Repair",
    "Samsung Note Series Repair",
    "Samsung Note 8 Repair",
    "Samsung Note 9 Repair",
    "Samsung S10 Repair",
    "Samsung S10 Plus Repair",
    "Samsung Galaxy Note 10 Repair",
    "Samsung Galaxy S20 Repair",
    "Samsung Galaxy Note 20 Repair",
    "iPhone 8 Repair",
    "iPhone X Repair",
    "Cart",
    "Checkout",
    "About Us",
    "Contact Us",
    "Services",
    "Dell Inspiron 15 3000 Laptop Power Adapter Charger 45W 65W Original"
]

brand = clean_brand_name("eFix Electronics Repair | Mobile Phone & Electronics Repair in Muwaileh Sharjah", "https://efix.ae")
print(f"Clean Brand Extracted: '{brand}'")
print("="*95)
print(f"{'PAGE TITLE':<35} | {'TLEN':<4} | {'MLEN':<4} | GENERATED TITLE")
print("="*95)
all_pass = True
for p in test_pages:
    t = generate_bulletproof_title(p, brand=brand)
    m = generate_bulletproof_meta(p, brand=brand)
    t_ok = 48 <= len(t) <= 60 and "..." not in t
    m_ok = 120 <= len(m) <= 155
    if not t_ok or not m_ok:
        all_pass = False
        status = "FAIL"
    else:
        status = "PASS"
    print(f"[{status}] {p[:32]:<32} | {len(t):<4} | {len(m):<4} | {t}")

print("="*95)
if all_pass:
    print(">>> 100% OF ALL TEST PAGES PASSED STRICT 48-60 CHAR & 120-155 CHAR RULES! <<<")
else:
    print(">>> SOME PAGES FAILED, INSPECT ABOVE <<<")
