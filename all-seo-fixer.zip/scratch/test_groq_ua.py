import urllib.request
import urllib.error
import json

headers = {
    'Authorization': 'Bearer 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',
    'Content-Type': 'application/json',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
}
body = {
    "model": "llama-3.3-70b-versatile",
    "messages": [{"role": "user", "content": "hi"}]
}
req = urllib.request.Request('https://api.groq.com/openai/v1/chat/completions', data=json.dumps(body).encode('utf-8'), headers=headers)
try:
    with urllib.request.urlopen(req) as resp:
        print('SUCCESS:', resp.read().decode())
except urllib.error.HTTPError as e:
    print('HTTP ERROR:', e.code, e.read().decode())
