import re

# View files
views = {
    'onpage.php': open('admin/views/onpage.php', 'r', encoding='utf-8').read(),
    'link-cleaner.php': open('admin/views/link-cleaner.php', 'r', encoding='utf-8').read(),
    'settings.php': open('admin/views/settings.php', 'r', encoding='utf-8').read(),
    'dashboard.php': open('admin/views/dashboard.php', 'r', encoding='utf-8').read(),
}

with open('assets/js/admin.js', 'r', encoding='utf-8') as f:
    js = f.read()

# Check elements bound in JS
test_ids = [
    ('asf-onpage-btn', 'onpage.php'),
    ('asf-onpage-bulk-autofix-btn', 'onpage.php'),
    ('asf-onpage-autolink-all-btn', 'onpage.php'),
    ('asf-onpage-type-filter', 'onpage.php'),
    ('asf-onpage-progress-bar', 'onpage.php'),
    ('asf-onpage-progress-fill', 'onpage.php'),
    ('asf-onpage-status', 'onpage.php'),
    ('asf-onpage-results', 'onpage.php'),
    
    ('asf-link-btn', 'link-cleaner.php'),
    ('asf-link-status', 'link-cleaner.php'),
    ('asf-link-results', 'link-cleaner.php'),
    ('asf-silo-autolink-btn', 'link-cleaner.php'),
    ('asf-view-targets-btn', 'link-cleaner.php'),
    ('asf-silo-progress-bar', 'link-cleaner.php'),
    ('asf-silo-progress-fill', 'link-cleaner.php'),
    ('asf-silo-status', 'link-cleaner.php'),
    ('asf-silo-results', 'link-cleaner.php'),
]

all_passed = True
for el_id, view_file in test_ids:
    content = views[view_file]
    if f'id="{el_id}"' in content or f"id='{el_id}'" in content:
        print(f"PASS: #{el_id} found in {view_file}")
    else:
        print(f"FAIL: #{el_id} NOT found in {view_file}")
        all_passed = False

# Dynamic IDs generated in JS
dynamic_ids = [
    'asf-onpage-table',
    'asf-qf-title',
    'asf-qf-desc',
    'asf-qf-keyword',
    'asf-qf-schema',
    'asf-qf-ai-autofill-btn',
    'asf-qf-autolink-btn',
    'asf-qf-save-btn',
    'asf-qf-msg',
    'asf-qf-link-status'
]

for did in dynamic_ids:
    if f'id="{did}"' in js or f"id='{did}'" in js:
        print(f"PASS: Dynamic #{did} created in admin.js")
    else:
        print(f"FAIL: Dynamic #{did} NOT created in admin.js")
        all_passed = False

if all_passed:
    print("\nALL BUTTONS, IDS, AND DOM TARGETS VERIFIED 100%!")
else:
    print("\nSOME IDS ARE MISSING!")
