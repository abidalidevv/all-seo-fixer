<?php
// Test extracting clean text and links from Elementor JSON
function extract_page_content_and_links( $post_content, $elementor_json = '' ) {
    $full_text = $post_content;
    $all_links = array();

    // Extract links from standard content
    if ( preg_match_all( '/<a[^>]+href=["\']([^"\']*)["\'][^>]*>/i', $post_content, $m ) ) {
        $all_links = array_merge( $all_links, $m[1] );
    }

    // If Elementor data exists
    if ( ! empty( $elementor_json ) && is_string( $elementor_json ) ) {
        $data = json_decode( $elementor_json, true );
        if ( is_array( $data ) ) {
            $extracted_texts = array();
            array_walk_recursive( $data, function( $value, $key ) use ( &$extracted_texts, &$all_links ) {
                if ( in_array( $key, array( 'title', 'editor', 'text', 'heading_title', 'html', 'description' ), true ) && is_string( $value ) ) {
                    $extracted_texts[] = $value;
                    if ( preg_match_all( '/<a[^>]+href=["\']([^"\']*)["\'][^>]*>/i', $value, $lm ) ) {
                        $all_links = array_merge( $all_links, $lm[1] );
                    }
                }
                if ( $key === 'url' && is_string( $value ) && ! empty( $value ) ) {
                    $all_links[] = $value;
                }
            } );
            if ( ! empty( $extracted_texts ) ) {
                $full_text .= ' ' . implode( ' ', $extracted_texts );
            }
        }
    }

    $clean_text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( strip_shortcodes( $full_text ) ) ) );
    $word_count = str_word_count( $clean_text );

    return array(
        'clean_text' => $clean_text,
        'word_count' => $word_count,
        'links'      => array_unique( $all_links ),
    );
}

// Dummy WordPress strip functions for CLI test
function wp_strip_all_tags($text) {
    return strip_tags($text);
}
function strip_shortcodes($text) {
    return preg_replace('/\[[^\]]+\]/', '', $text);
}

$sample_raw_content = '<div class="elementor">Shortcode content only</div>';
$sample_elementor = json_encode( array(
    array(
        'id' => 'sec1',
        'elements' => array(
            array(
                'widgetType' => 'heading',
                'settings' => array( 'title' => 'Professional iPhone & MacBook Repair Services Dubai' )
            ),
            array(
                'widgetType' => 'text-editor',
                'settings' => array( 'editor' => '<p>We provide high quality repair services for all Apple devices including iPhone screen replacement, battery repair, MacBook motherboard diagnostic and data recovery. <a href="https://efix.ae/product-category/iphone/">Explore iPhone Models</a></p>' )
            ),
            array(
                'widgetType' => 'button',
                'settings' => array(
                    'text' => 'Book Repair',
                    'link' => array( 'url' => 'https://efix.ae/contact/' )
                )
            )
        )
    )
) );

$res = extract_page_content_and_links( $sample_raw_content, $sample_elementor );
echo "Word count: " . $res['word_count'] . "\n";
echo "Links count: " . count($res['links']) . "\n";
print_r($res['links']);
