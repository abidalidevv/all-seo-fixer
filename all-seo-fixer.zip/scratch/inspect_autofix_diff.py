import subprocess, sys

sys.stdout.reconfigure(encoding='utf-8')
res = subprocess.run(['git', 'diff', '-w', '52af60b', '--', 'includes/class-asf-handlers.php'], capture_output=True)
diff = res.stdout.decode('utf-8', errors='replace')

lines = diff.splitlines()
in_autofix = False
autofix_diff = []

for line in lines:
    if 'class ASF_AutoFixer' in line or 'class ASF_AIChatbot' in line:
        in_autofix = True
    if in_autofix:
        autofix_diff.append(line)

print('\n'.join(autofix_diff[:350]))
