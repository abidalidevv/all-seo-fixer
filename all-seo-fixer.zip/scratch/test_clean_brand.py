import re

def clean_brand_name(site_title, home_url='https://efix.ae'):
    site_title = (site_title or '').strip()
    if not site_title or site_title.lower() == 'wordpress':
        host = home_url.replace('https://', '').replace('http://', '').split('/')[0]
        brand = re.sub(r'^www\.', '', host, flags=re.I)
        brand = re.sub(r'\.[a-z]{2,6}$', '', brand, flags=re.I)
        return brand.capitalize()
    
    # Split by delimiters
    for delim in ['|', '—', '–', '-', ':', '•']:
        if delim in site_title:
            site_title = site_title.split(delim)[0].strip()
            break
            
    # Check if domain matches prefix (e.g. efix in "eFix Electronics Repair")
    host = home_url.replace('https://', '').replace('http://', '').split('/')[0]
    short_host = re.sub(r'^www\.', '', host, flags=re.I)
    short_host = re.sub(r'\.[a-z]{2,6}$', '', short_host, flags=re.I) # efix
    
    if short_host.lower() in site_title.lower() and len(site_title) > 12:
        m = re.match(r'^(' + re.escape(short_host) + r')\b', site_title, flags=re.I)
        if m:
            return m.group(1)
        # Check first word
        first_word = site_title.split()[0]
        if first_word.lower() == short_host.lower():
            return first_word
            
    if len(site_title) > 12:
        site_title = site_title.split()[0]
    return site_title[:12] if site_title else 'eFix'

raw_site = "eFix Electronics Repair | Mobile Phone & Electronics Repair in Muwaileh Sharjah"
brand = clean_brand_name(raw_site)
print(f"Original Site Title: '{raw_site}'")
print(f"Clean Short Brand:   '{brand}'")
