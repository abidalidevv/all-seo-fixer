import sys
import re

sys.stdout.reconfigure(encoding='utf-8')

with open('includes/class-asf-handlers.php', 'r', encoding='utf-8') as f:
    content = f.read()

classes = re.findall(r'class\s+([A-Za-z0-9_]+)', content)
print('CLASSES:', classes)

ajax_hooks = re.findall(r"add_action\(\s*['\"]wp_ajax_([^'\"]+)['\"]\s*,\s*array\(\s*([A-Za-z0-9_:]+)\s*,\s*['\"]([^'\"]+)['\"]\s*\)\s*\);", content)
for hook, cls, method in ajax_hooks:
    print(f'AJAX: {hook} -> {cls}::{method}')
