var asfData = {
    siteName: 'eFix Electronics Repair | Mobile Phone & Electronics Repair in Muwaileh Sharjah',
    cleanBrand: 'eFix'
};

function getAsfData() {
    return asfData;
}

function getCleanBrandJS() {
    var data = getAsfData();
    var site = (data.cleanBrand || data.siteName || '').trim();
    ['|', '—', '–', ' - ', ':', '•'].forEach(function(d) {
        if (site.indexOf(d) !== -1) {
            site = site.split(d)[0].trim();
        }
    });
    if (!site || site.toLowerCase() === 'wordpress') {
        site = 'eFix';
    }
    if (site.length > 15) {
        var words = site.split(/\s+/);
        site = words[0];
    }
    return site || 'eFix';
}

function generateSmartTitleJS(pTitle, postType, url) {
    pTitle = (pTitle || 'Page').trim();
    var brand = getCleanBrandJS();
    var cleaned = pTitle.replace(new RegExp('\\s*([|\\-–—:]\\s*(' + brand + '|Official Site|WordPress|Electronics Repair|Mobile Phone)).*$', 'i'), '').trim();
    if (!cleaned) cleaned = pTitle;

    var lower = cleaned.toLowerCase();
    var urlLower = (url || '').toLowerCase();
    var brandSuf = ' | ' + brand;

    if (lower === 'cart' || urlLower.indexOf('/cart') !== -1) {
        return ('Your Shopping Cart & Secure Online Checkout | ' + brand + ' UAE').substring(0, 60);
    }
    if (lower === 'checkout' || urlLower.indexOf('/checkout') !== -1) {
        return ('Secure Checkout & Fast Order Completion in UAE | ' + brand).substring(0, 60);
    }
    if (lower === 'home' || lower === 'homepage' || urlLower.indexOf('/home') !== -1) {
        return ('Expert Device & Electronics Repair in Dubai | ' + brand).substring(0, 60);
    }
    if (lower.indexOf('contact') !== -1) {
        return ('Contact Us & Repair Service Center Location | ' + brand + ' UAE').substring(0, 60);
    }
    if (lower.indexOf('about') !== -1) {
        return ('About Us & Certified Technicians Team | ' + brand + ' UAE').substring(0, 60);
    }
    if (lower === 'services' || lower === 'service' || lower === 'our services' || urlLower.indexOf('/services') !== -1) {
        return ('Certified Device Repair & Screen Services | ' + brand).substring(0, 60);
    }

    var candidates = [];
    if (lower.indexOf('iphone') !== -1) {
        candidates = [
            cleaned + ' Screen & Battery Fix in Dubai' + brandSuf,
            cleaned + ' Screen & Battery Replacement' + brandSuf,
            cleaned + ' - Same Day Screen Repair in UAE' + brandSuf,
            cleaned + ' - Fast Screen & Battery Fix | ' + brand + ' UAE',
            cleaned + ' Screen & Glass Repair in Dubai | ' + brand,
            cleaned + ' - Expert Diagnostics & Fix' + brandSuf,
            cleaned + ' Screen & Battery Repair | ' + brand + ' UAE',
            cleaned + ' - Certified Screen Fix in Dubai | ' + brand
        ];
    } else if (lower.indexOf('samsung') !== -1 || lower.indexOf('galaxy') !== -1 || lower.indexOf('note') !== -1 || lower.indexOf('series') !== -1) {
        candidates = [
            cleaned + ' Screen & Glass Repair | ' + brand + ' UAE',
            cleaned + ' Screen & Battery Fix in Dubai' + brandSuf,
            cleaned + ' Screen & Battery Replacement' + brandSuf,
            cleaned + ' - Fast Screen & Glass Repair' + brandSuf,
            cleaned + ' - Genuine Screen Replacement | ' + brand,
            cleaned + ' - Fast Repairs & Screen Fix' + brandSuf,
            cleaned + ' Screen & Battery Fix | ' + brand + ' UAE',
            cleaned + ' - Certified Mobile Repair | ' + brand
        ];
    } else if (lower.indexOf('macbook') !== -1 || lower.indexOf('imac') !== -1 || lower.indexOf('laptop') !== -1 || lower.indexOf('surface') !== -1 || lower.indexOf('computer') !== -1) {
        candidates = [
            cleaned + ' & Screen Fix in Dubai | ' + brand,
            cleaned + ' & Screen Replacement in UAE | ' + brand,
            cleaned + ' - Fast Hardware Fix in Dubai | ' + brand,
            cleaned + ' - Screen & Battery Fix in Dubai | ' + brand,
            cleaned + ' & Motherboard Repair in Dubai | ' + brand,
            cleaned + ' - Fast Diagnostics & Repair | ' + brand,
            cleaned + ' & Hardware Repair Service | ' + brand + ' UAE',
            cleaned + ' - Expert Screen & Battery Fix | ' + brand
        ];
    } else if (lower.indexOf('tablet') !== -1 || lower.indexOf('ipad') !== -1) {
        candidates = [
            cleaned + ' Screen & Battery Fix in Dubai' + brandSuf,
            cleaned + ' Screen & Battery Fix in Dubai | ' + brand + ' UAE',
            cleaned + ' Screen & Glass Replacement' + brandSuf,
            cleaned + ' Screen & Battery Replacement | ' + brand,
            cleaned + ' - Fast Certified Repair in Dubai | ' + brand,
            cleaned + ' & Hardware Fix | ' + brand + ' UAE',
            cleaned + ' - Same Day Screen Fix in Dubai | ' + brand,
            cleaned + ' - Fast Screen & Glass Fix | ' + brand + ' UAE'
        ];
    } else if (lower.indexOf('repair') !== -1 || lower.indexOf('fix') !== -1 || postType === 'page') {
        candidates = [
            cleaned + ' - Fast Certified Service in Dubai' + brandSuf,
            cleaned + ' & Diagnostics Service in UAE' + brandSuf,
            cleaned + ' - Expert Same Day Fix in Dubai | ' + brand,
            cleaned + ' & Screen Replacement in Dubai | ' + brand,
            cleaned + ' - Professional Repair in UAE | ' + brand,
            cleaned + ' | Certified Fast Repair in Dubai'
        ];
    } else {
        candidates = [
            cleaned + ' - Buy Online with Warranty | ' + brand + ' UAE',
            'Certified ' + cleaned + ' - Best Deals in UAE | ' + brand,
            cleaned + ' — Complete Overview & Specs | ' + brand + ' UAE',
            cleaned + ' - Fast Delivery in UAE | ' + brand,
            cleaned + ' | Official Guide & Store | ' + brand
        ];
    }

    for (var i = 0; i < candidates.length; i++) {
        var c = candidates[i];
        if (c.length >= 48 && c.length <= 60) return c;
    }

    var padOptions = [
        ' in Dubai & Sharjah | ' + brand,
        ' - Certified Service in Dubai | ' + brand,
        ' - Fast Same Day Fix | ' + brand + ' UAE',
        ' Screen & Battery Fix | ' + brand + ' UAE',
        ' Repair & Fix in Dubai | ' + brand,
        ' | ' + brand + ' Dubai Repair Center',
        ' | ' + brand + ' UAE',
        ' | ' + brand
    ];
    for (var j = 0; j < padOptions.length; j++) {
        var cand = cleaned + padOptions[j];
        if (cand.length >= 48 && cand.length <= 60) return cand;
    }

    if ((cleaned + brandSuf).length > 60) {
        var maxBase = 60 - brandSuf.length;
        var sub = cleaned.substring(0, maxBase);
        var lsp = sub.lastIndexOf(' ');
        if (lsp > 15) sub = sub.substring(0, lsp);
        return sub + brandSuf;
    }
    return (cleaned + brandSuf).substring(0, 60);
}

function generateMetaDescFromData(title, snippet, postType, url) {
    title = (title || 'Page').trim();
    var brand = getCleanBrandJS();
    var cleaned = title.replace(new RegExp('\\s*([|\\-–—:]\\s*(' + brand + '|Official Site|WordPress|Electronics Repair|Mobile Phone)).*$', 'i'), '').trim();
    if (!cleaned) cleaned = title;

    var lower = cleaned.toLowerCase();
    var urlLower = (url || '').toLowerCase();

    if (urlLower.indexOf('/cart') !== -1 || lower === 'cart' || lower.indexOf('cart') !== -1) {
        return 'Review items in your shopping cart at ' + brand + '. Enjoy fast, secure checkout, warranty coverage, and dedicated customer support across UAE.';
    }
    if (urlLower.indexOf('/checkout') !== -1 || lower === 'checkout' || lower.indexOf('checkout') !== -1) {
        return 'Complete your secure order at ' + brand + '. Safe encrypted payments, verified warranties, and rapid doorstep delivery. Finish your purchase now!';
    }
    if (urlLower.indexOf('/services') !== -1 || lower === 'services' || lower === 'service' || lower === 'our services') {
        return 'Explore professional electronics and gadget repair services at ' + brand + '. Certified technicians, genuine parts, fast turnaround, and full warranty.';
    }

    var cand1 = 'Need expert ' + cleaned + '? ' + brand + ' provides fast same-day diagnostics, genuine parts, and warranty-backed repairs in Dubai & Sharjah. Contact us today!';
    var cand2 = 'Professional ' + cleaned + ' at ' + brand + '. Certified technicians, genuine replacement parts, quick turnaround, and full warranty coverage across UAE. Call now!';
    var cand3 = 'Looking for trusted ' + cleaned + '? ' + brand + ' offers certified repairs, original parts, and fast service in Dubai & Sharjah. Book your repair online today!';

    var metas = [cand1, cand2, cand3];
    for (var i = 0; i < metas.length; i++) {
        if (metas[i].length >= 120 && metas[i].length <= 155) return metas[i];
    }

    if (cand1.length > 155) {
        var sub = cand1.substring(0, 150);
        var lsp = sub.lastIndexOf(' ');
        if (lsp > 100) sub = sub.substring(0, lsp);
        var res = sub.replace(/[.,:;\s-]+$/, '') + '. Book online today!';
        if (res.length <= 155) return res;
        return sub.replace(/[.,:;\s-]+$/, '') + '.';
    }
    if (cand1.length < 120) {
        return cand1.replace(/[.\s]+$/, '') + '. Contact our expert technicians today!';
    }
    return cand1;
}

var testPages = [
    "Acer Laptop Repair",
    "Asus Laptop Repair",
    "Microsoft Surface Pro Repair",
    "Apple iMac Repair",
    "Apple Macbook Pro Repair",
    "Apple Macbook Air Repair",
    "Other Tablet Repair",
    "Android Tablet Repair",
    "Asus Tablet Repair",
    "Acer Tablet Repair",
    "Lenovo Tablet Repair",
    "Other Samsung Device Repair",
    "Samsung A Series Repair",
    "Samsung J Series Repair",
    "Samsung Note Series Repair",
    "Samsung Note 8 Repair",
    "Samsung Note 9 Repair",
    "Samsung S10 Repair",
    "Samsung S10 Plus Repair",
    "Samsung Galaxy Note 10 Repair",
    "Samsung Galaxy S20 Repair",
    "Samsung Galaxy Note 20 Repair",
    "iPhone 8 Repair",
    "iPhone X Repair",
    "Cart",
    "Checkout",
    "About Us",
    "Contact Us",
    "Services"
];

console.log("Clean Brand:", getCleanBrandJS());
var allPassed = true;
testPages.forEach(function(p) {
    var t = generateSmartTitleJS(p, 'page', 'https://efix.ae/' + p.toLowerCase().replace(/\s+/g, '-'));
    var m = generateMetaDescFromData(p, '', 'page', 'https://efix.ae/' + p.toLowerCase().replace(/\s+/g, '-'));
    var tOk = t.length >= 48 && t.length <= 60 && t.indexOf('...') === -1;
    var mOk = m.length >= 120 && m.length <= 155;
    if (!tOk || !mOk) allPassed = false;
    var stat = (tOk && mOk) ? 'PASS' : 'FAIL';
    console.log('[' + stat + '] ' + (p + '                              ').substring(0, 32) + ' | ' + t.length + ' | ' + m.length + ' | ' + t);
});

if (allPassed) {
    console.log(">>> ALL JS TEST PAGES PASSED 48-60 CHARS & 120-155 CHARS STRICTLY! <<<");
} else {
    console.log(">>> SOME JS PAGES FAILED! <<<");
    process.exit(1);
}
