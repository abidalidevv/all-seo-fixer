import urllib.request
import json

api_key = "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"
url = "https://api.groq.com/openai/v1/chat/completions"

system_prompt = """You are an elite Senior SEO Architect for eFix (https://efix.ae), an electronics and device repair center in Dubai and Sharjah, UAE.
Generate click-compelling, high-ranking SEO metadata tailored specifically to the requested page topic.
Output strictly valid JSON with keys: 'title', 'meta_desc', 'focus_keyword'.

RULES FOR TITLE:
- Length: strictly 48 to 60 characters.
- MUST be unique, highly specific to the device/service, and include high-intent terms (e.g. Screen Replacement, Battery Fix, Repair in Dubai).
- Brand suffix: use ONLY ' | eFix' or ' | eFix Dubai' or ' | eFix UAE' (keep brand under 12 chars).
- NEVER append the full business description, tagline, or long address in the title!
- NEVER exceed 60 characters."""

user_prompt = """Generate optimal SEO metadata for this page:
- Page Title: iPhone 8 Repair
- Post Type: page
- URL: https://efix.ae/iphone-8-repair/
- Category: iPhone Repair
- Brand: eFix"""

payload = {
    "model": "llama-3.3-70b-versatile",
    "messages": [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ],
    "response_format": {"type": "json_object"},
    "temperature": 0.3
}

req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers={
    "Content-Type": "application/json",
    "Authorization": f"Bearer {api_key}"
})

try:
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read().decode('utf-8'))
        content = data['choices'][0]['message']['content']
        parsed = json.loads(content)
        title = parsed.get('title', '')
        print("TITLE:", title)
        print("LENGTH:", len(title))
        print("META:", parsed.get('meta_desc', ''))
        print("META LENGTH:", len(parsed.get('meta_desc', '')))
        print("KEYWORD:", parsed.get('focus_keyword', ''))
except Exception as e:
    print("Error:", e)
