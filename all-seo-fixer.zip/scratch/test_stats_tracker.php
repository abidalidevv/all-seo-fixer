<?php
define('ABSPATH', 1);
$GLOBALS['wp_options'] = array();

function get_option($key, $default = false) {
    return isset($GLOBALS['wp_options'][$key]) ? $GLOBALS['wp_options'][$key] : $default;
}

function update_option($key, $value, $autoload = null) {
    $GLOBALS['wp_options'][$key] = $value;
    return true;
}

function delete_option($key) {
    unset($GLOBALS['wp_options'][$key]);
    return true;
}

function wp_parse_args($args, $defaults = '') {
    if (is_object($args)) {
        $r = get_object_vars($args);
    } elseif (is_array($args)) {
        $r =& $args;
    } else {
        $r = array();
    }
    if (is_array($defaults)) {
        return array_merge($defaults, $r);
    }
    return $r;
}

function current_time($type) {
    if ($type === 'mysql') return date('Y-m-d H:i:s');
    return time();
}

function add_action($tag, $callback) {}

// Include class definition
require_once __DIR__ . '/../includes/class-asf-handlers.php';

echo "Testing ASF_StatsTracker in isolation...\n";

// 1. Initial stats check
$init = ASF_StatsTracker::get_stats();
assert($init['total_fixes'] === 0, "Initial fixes should be 0");
echo "✓ Initial stats are 0\n";

// 2. Record Title & Meta Fix
$s1 = ASF_StatsTracker::record_fix('title_and_meta', 1, 'Used iPhone 12 Pro Max');
assert($s1['total_fixes'] === 1, "Total fixes should be 1");
assert($s1['titles_fixed'] === 1, "Titles fixed should be 1");
assert($s1['metas_fixed'] === 1, "Metas fixed should be 1");
assert(count($s1['recent_activity']) === 1, "Recent activity count should be 1");
echo "✓ Recorded title_and_meta fix correctly\n";

// 3. Record Internal Link Fix
$s2 = ASF_StatsTracker::record_fix('internal_link', 3, 'Services Page');
assert($s2['total_fixes'] === 4, "Total fixes should be 4 (1 + 3)");
assert($s2['links_generated'] === 3, "Links generated should be 3");
assert(count($s2['recent_activity']) === 2, "Recent activity count should be 2");
echo "✓ Recorded internal_link fix correctly\n";

// 4. Record Alt Text Fix
$s3 = ASF_StatsTracker::record_fix('alt', 5, 'Media Library');
assert($s3['total_fixes'] === 9, "Total fixes should be 9 (4 + 5)");
assert($s3['alts_fixed'] === 5, "Alts fixed should be 5");
echo "✓ Recorded alt text fix correctly\n";

// 5. Test Persistence via get_stats()
$persisted = ASF_StatsTracker::get_stats();
assert($persisted['total_fixes'] === 9, "Persisted total fixes should be 9");
assert($persisted['titles_fixed'] === 1, "Persisted titles should be 1");
assert($persisted['metas_fixed'] === 1, "Persisted metas should be 1");
assert($persisted['links_generated'] === 3, "Persisted links should be 3");
assert($persisted['alts_fixed'] === 5, "Persisted alts should be 5");
echo "✓ Persistent state in wp_options validated 100%!\n";

echo "\n🎉 ALL ASF_STATSTRACKER UNIT TESTS PASSED!\n";
