import re

html_content = '''
<p>Welcome to our center. We provide expert iphone repair services for all models. Our team is certified.</p>
<h2>Why Choose Our iPhone Repair Shop?</h2>
<p>If you need an iphone repair, check our <a href="https://efix.ae/services/">services list</a>. We also fix macbook screen issues.</p>
<div class="iphone repair" data-item="iphone repair"><img src="iphone-repair.jpg" alt="iphone repair" /></div>
<p>Visit us for macbook screen replacement today.</p>
'''

targets = [
    {'keyword': 'iphone repair', 'url': 'https://efix.ae/product-category/iphone-repair/', 'name': 'iPhone Repair'},
    {'keyword': 'macbook screen', 'url': 'https://efix.ae/product-category/macbook-screen/', 'name': 'MacBook Screen'}
]

def safe_auto_link(content, targets, max_links=3):
    tag_regex = re.compile(r'(</?[a-zA-Z0-9]+(?:\s+[^>]*?)?>|<!--[\s\S]*?-->)')
    tokens = tag_regex.split(content)
    
    in_forbidden_tag = 0
    forbidden_tags = {'a', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'script', 'style', 'button'}
    
    links_added = 0
    used_targets = set()
    
    new_tokens = []
    for token in tokens:
        if not token:
            continue
        tag_match = re.match(r'^<(/)?([a-zA-Z0-9]+)', token)
        if tag_match:
            is_closing = bool(tag_match.group(1))
            tag_name = tag_match.group(2).lower()
            if tag_name in forbidden_tags:
                if is_closing:
                    in_forbidden_tag = max(0, in_forbidden_tag - 1)
                else:
                    in_forbidden_tag += 1
            new_tokens.append(token)
        else:
            if in_forbidden_tag == 0 and links_added < max_links:
                for target in targets:
                    if links_added >= max_links:
                        break
                    kw = target['keyword']
                    if kw.lower() in used_targets:
                        continue
                    
                    pattern = re.compile(r'\b(' + re.escape(kw) + r')\b', re.IGNORECASE)
                    if pattern.search(token):
                        def repl(m):
                            nonlocal links_added
                            links_added += 1
                            used_targets.add(kw.lower())
                            matched_text = m.group(1)
                            return f'<a href="{target["url"]}" title="{target["name"]}">{matched_text}</a>'
                        token = pattern.sub(repl, token, count=1)
            new_tokens.append(token)
            
    return ''.join(new_tokens), links_added

result, count = safe_auto_link(html_content, targets)
print(f"Links added: {count}")
print("Result HTML:")
print(result)
