import re

def clean_brand_name(site_title, home_url='https://example.com'):
    site_title = (site_title or '').strip()
    host = home_url.replace('https://', '').replace('http://', '').split('/')[0]
    domain_brand = re.sub(r'^www\.', '', host, flags=re.I)
    domain_brand = re.sub(r'\.[a-z]{2,6}$', '', domain_brand, flags=re.I)
    default_brand = domain_brand.capitalize() if domain_brand else 'Brand'

    if not site_title or site_title.lower() == 'wordpress':
        return default_brand

    # Split by delimiters |, —, –, -, :, •
    for delim in ['|', '—', '–', ' - ', ':', '•']:
        if delim in site_title:
            site_title = site_title.split(delim)[0].strip()
            break

    # If site_title is long (>15 chars) and has domain brand or generic words
    if len(site_title) > 15:
        words = site_title.split()
        if words and words[0].lower() == domain_brand.lower():
            return words[0]
        cleaned = re.sub(r'\b(Official\s*Site|Store|Shop|Blog|Company|Agency|Services?)\b.*$', '', site_title, flags=re.I).strip()
        if cleaned and len(cleaned) <= 15:
            return cleaned
        if words:
            return words[0]

    return site_title if site_title else default_brand

def generate_universal_title(p_title, post_type='page', brand='Brand'):
    raw = p_title.strip()
    cleaned = re.sub(r'\s*([|\-–—:]\s*' + re.escape(brand) + r').*$', '', raw, flags=re.I).strip()
    if not cleaned: cleaned = raw

    lower = cleaned.lower()
    brand_suf = f" | {brand}"

    # Standard pages
    if lower in ['cart', 'shopping cart'] or 'cart' in lower:
        candidates = [
            f"Your Shopping Cart & Secure Online Checkout{brand_suf}",
            f"View Your Shopping Cart & Checkout Online{brand_suf}",
            f"Secure Shopping Cart & Order Checkout{brand_suf}",
        ]
    elif lower in ['checkout'] or 'checkout' in lower:
        candidates = [
            f"Secure Checkout & Fast Order Confirmation{brand_suf}",
            f"Complete Your Order & Secure Online Checkout{brand_suf}",
            f"Secure Checkout & Quick Order Completion{brand_suf}",
        ]
    elif lower in ['home', 'homepage']:
        candidates = [
            f"Welcome to Official Website & Services{brand_suf}",
            f"Official Website & Professional Solutions{brand_suf}",
            f"Home - Trusted Quality & Professional Care{brand_suf}",
        ]
    elif 'contact' in lower:
        candidates = [
            f"Contact Us & Customer Support Helpdesk{brand_suf}",
            f"Get in Touch & Dedicated Customer Support{brand_suf}",
            f"Contact Our Support Team & Store Location{brand_suf}",
        ]
    elif 'about' in lower:
        candidates = [
            f"About Us, Our Company Mission & Expert Team{brand_suf}",
            f"About Us & Dedicated Professional Team{brand_suf}",
            f"About Our Company, History & Values{brand_suf}",
        ]
    elif lower in ['services', 'service', 'our services']:
        candidates = [
            f"Professional Services & Expert Solutions{brand_suf}",
            f"Comprehensive Services & Trusted Solutions{brand_suf}",
            f"Expert Services, Certified Quality & Care{brand_suf}",
        ]
    elif any(k in lower for k in ['repair', 'fix', 'restore', 'maintenance', 'support', 'diagnostic']):
        # UNIVERSAL REPAIR & TECHNICAL: covers ALL issues (screen, battery, touch, button, power loss, motherboard, diagnostics)
        candidates = [
            f"{cleaned} - Complete Repair & Diagnostics{brand_suf}",
            f"{cleaned} - Expert Diagnostics & Full Fix{brand_suf}",
            f"{cleaned} - Fast, Certified Repair Service{brand_suf}",
            f"{cleaned} - Professional Hardware & Tech Fix{brand_suf}",
            f"{cleaned} - Trusted Diagnostics & Repair{brand_suf}",
            f"{cleaned} - Comprehensive Service & Fix{brand_suf}",
            f"{cleaned} - Complete Hardware & System Fix{brand_suf}",
            f"{cleaned} - Full Diagnostics & Hardware Fix{brand_suf}",
            f"{cleaned} - Expert Service & Diagnostics{brand_suf}",
            f"{cleaned} - Professional Certified Repair{brand_suf}",
            f"{cleaned} - Complete Multi-Point Repair{brand_suf}",
            f"{cleaned} - Fast, Reliable Repair Service{brand_suf}",
            f"{cleaned} - Same-Day Certified Repair{brand_suf}",
            f"{cleaned} - Expert Hardware Repair & Fix{brand_suf}",
            f"{cleaned} - Complete Diagnostics & Fix{brand_suf}",
            f"{cleaned} - Trusted Repair & Support{brand_suf}",
        ]
    elif post_type == 'product' or any(k in lower for k in ['buy', 'shop', 'order', 'adapter', 'charger', 'shoes', 'phone', 'laptop', 'camera']):
        candidates = [
            f"Buy {cleaned} Online with Warranty{brand_suf}",
            f"Original {cleaned} - Certified Quality & Deals{brand_suf}",
            f"{cleaned} - Best Online Deals & Fast Delivery{brand_suf}",
            f"Order {cleaned} Online - Guaranteed Quality{brand_suf}",
            f"{cleaned} - Specifications, Price & Warranty{brand_suf}",
            f"Buy {cleaned} Online - Best Price & Warranty{brand_suf}",
            f"{cleaned} - Premium Quality & Fast Shipping{brand_suf}",
        ]
    else:
        candidates = [
            f"{cleaned} — Complete Overview & Guide{brand_suf}",
            f"{cleaned} - Expert Insights & Full Overview{brand_suf}",
            f"{cleaned} - Comprehensive Guide & Details{brand_suf}",
            f"{cleaned} - Complete Information & Guide{brand_suf}",
            f"{cleaned} - Trusted Solutions & Overview{brand_suf}",
            f"{cleaned} - Professional Overview & Guide{brand_suf}",
            f"{cleaned} - Official Guide & Details{brand_suf}",
            f"{cleaned} - Trusted Insights & Guide{brand_suf}",
        ]

    for cand in candidates:
        if 48 <= len(cand) <= 60:
            return cand

    # Dynamic graduated padding based on available budget (mathematically covers all lengths)
    pad_options = [
        f" - Complete Comprehensive Services & Support{brand_suf}",
        f" - Professional Service & Expert Support{brand_suf}",
        f" - Complete Overview & Comprehensive Guide{brand_suf}",
        f" - Professional Solutions & Trusted Care{brand_suf}",
        f" - Expert Diagnostics & Full Solutions{brand_suf}",
        f" - Comprehensive Services & Support{brand_suf}",
        f" - Professional Service & Support{brand_suf}",
        f" - Complete Overview & Guide{brand_suf}",
        f" - Professional Services & Care{brand_suf}",
        f" - Expert Solutions & Overview{brand_suf}",
        f" - Trusted Services & Support{brand_suf}",
        f" - Complete Diagnostic Service{brand_suf}",
        f" - Professional Solutions{brand_suf}",
        f" - Expert Guide & Details{brand_suf}",
        f" - Trusted Quality & Care{brand_suf}",
        f" - Comprehensive Services{brand_suf}",
        f" - Professional Services{brand_suf}",
        f" - Official Specifications{brand_suf}",
        f" - Expert Solutions{brand_suf}",
        f" - Trusted Services{brand_suf}",
        f" - Complete Overview{brand_suf}",
        f" - Complete Guide{brand_suf}",
        f" - Full Overview{brand_suf}",
        f" - Expert Care{brand_suf}",
        f" - Solutions{brand_suf}",
        f" - Overview{brand_suf}",
        f" - Guide{brand_suf}",
        f"{brand_suf}",
    ]
    for pad in pad_options:
        cand = cleaned + pad
        if 48 <= len(cand) <= 60:
            return cand

    if len(cleaned + brand_suf) > 60:
        max_base = 60 - len(brand_suf)
        sub = cleaned[:max_base].rsplit(' ', 1)[0]
        return sub + brand_suf

    return (cleaned + brand_suf)[:60]

def generate_universal_meta(p_title, post_type='page', brand='Brand'):
    raw = p_title.strip()
    cleaned = re.sub(r'\s*([|\-–—:]\s*' + re.escape(brand) + r').*$', '', raw, flags=re.I).strip()
    if not cleaned: cleaned = raw

    lower = cleaned.lower()

    if lower in ['cart', 'shopping cart'] or 'cart' in lower:
        return f"Review items in your shopping cart at {brand}. Enjoy fast, secure checkout, verified warranty, and dedicated support. Finish your order today!"[:155]
    if lower in ['checkout'] or 'checkout' in lower:
        return f"Complete your secure order at {brand}. Safe encrypted payments, verified guarantees, and fast delivery to your door. Finish your purchase now!"[:155]
    if lower in ['services', 'service', 'our services']:
        return f"Explore professional services and trusted solutions at {brand}. Certified specialists, proven quality, and dedicated support. Get in touch today!"[:155]

    cand1 = f"Get complete details and professional solutions for {cleaned} at {brand}. Certified expertise, verified quality, and fast assistance. Contact us today!"
    cand2 = f"Discover trusted {cleaned} with {brand}. Certified specialists, high quality standards, reliable results, and full support. Book or order online today!"
    cand3 = f"Looking for expert {cleaned}? {brand} provides comprehensive solutions, verified quality, and dedicated customer care. Explore our options now!"

    for c in [cand1, cand2, cand3]:
        if 120 <= len(c) <= 155:
            return c

    if len(cand1) > 155:
        sub = cand1[:150].rsplit(' ', 1)[0].rstrip('.,:;-') + '. Contact us today!'
        if len(sub) > 155:
            sub = cand1[:152].rsplit(' ', 1)[0].rstrip('.,:;-') + '.'
        return sub

    if len(cand1) < 120:
        return cand1.rstrip('.') + " Contact our expert team today!"

    return cand1[:155]

# Test on diverse websites:
test_cases = [
    # 1. Device repair site (eFix test site)
    ("eFix", "https://efix.ae", [
        "Acer Laptop Repair",
        "Asus Laptop Repair",
        "Microsoft Surface Pro Repair",
        "Apple iMac Repair",
        "Apple Macbook Pro Repair",
        "Apple Macbook Air Repair",
        "Other Tablet Repair",
        "Android Tablet Repair",
        "Asus Tablet Repair",
        "Acer Tablet Repair",
        "Lenovo Tablet Repair",
        "Other Samsung Device Repair",
        "Samsung A Series Repair",
        "Samsung J Series Repair",
        "Samsung Note Series Repair",
        "Samsung Note 8 Repair",
        "Samsung Note 9 Repair",
        "Samsung S10 Repair",
        "Samsung S10 Plus Repair",
        "Samsung Galaxy Note 10 Repair",
        "Samsung Galaxy S20 Repair",
        "Samsung Galaxy Note 20 Repair",
        "iPhone 8 Repair",
        "iPhone X Repair",
    ]),
    # 2. Dental clinic site
    ("SmileDental", "https://smiledental.com", [
        "Dental Implant Surgery",
        "Teeth Whitening Service",
        "Root Canal Treatment",
        "Orthodontic Clear Braces",
        "Emergency Dental Care",
        "Pediatric Dentistry",
    ]),
    # 3. Fashion & Apparel store
    ("VogueStore", "https://voguestore.com", [
        "Men Slim Fit Cotton Shirt",
        "Women Leather Crossbody Bag",
        "Casual Canvas Sneakers",
        "Winter Wool Trench Coat",
    ]),
    # 4. Law firm / Legal consultancy
    ("ApexLaw", "https://apexlaw.org", [
        "Corporate Law & Contracts",
        "Personal Injury Representation",
        "Intellectual Property Protection",
        "Immigration & Visa Assistance",
    ]),
    # 5. Core site pages
    ("ApexLaw", "https://apexlaw.org", [
        "Cart",
        "Checkout",
        "About Us",
        "Contact Us",
        "Our Services",
    ])
]

print("="*100)
print(f"{'BRAND':<12} | {'PAGE TITLE':<32} | {'TLEN':<4} | {'MLEN':<4} | GENERATED TITLE")
print("="*100)

all_ok = True
for brand, url, pages in test_cases:
    clean_brand = clean_brand_name(brand, url)
    for p in pages:
        t = generate_universal_title(p, brand=clean_brand)
        m = generate_universal_meta(p, brand=clean_brand)
        t_ok = 48 <= len(t) <= 60 and "..." not in t
        m_ok = 120 <= len(m) <= 155
        if not t_ok or not m_ok:
            all_ok = False
            status = "FAIL"
        else:
            status = "PASS"
        print(f"[{status}] {clean_brand:<10} | {p[:30]:<30} | {len(t):<4} | {len(m):<4} | {t}")

print("="*100)
if all_ok:
    print(">>> 100% OF ALL DIVERSE WEBSITES & NICHES PASSED STRICT 48-60 CHAR & 120-155 CHAR RULES! <<<")
else:
    print(">>> SOME TEST CASES FAILED <<<")
