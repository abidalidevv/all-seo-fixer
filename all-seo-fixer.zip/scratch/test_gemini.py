import urllib.request
import urllib.error
import json

gemini_key = "AIzaSyBncUXbZ34vYpS_-snCT3GZwgB8Jn1TT-c"
url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={gemini_key}"
body = {
    "contents": [{"parts": [{"text": "Hello"}]}]
}
req = urllib.request.Request(url, data=json.dumps(body).encode('utf-8'), headers={'Content-Type': 'application/json'})
try:
    with urllib.request.urlopen(req) as resp:
        print("GEMINI SUCCESS:", resp.read().decode())
except urllib.error.HTTPError as e:
    print("GEMINI HTTP ERROR:", e.code, e.read().decode())
