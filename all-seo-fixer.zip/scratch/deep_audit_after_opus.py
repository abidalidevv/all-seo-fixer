import subprocess
import re

# 1. Run git diff -w against 52af60b
res = subprocess.run(['git', 'diff', '-w', '52af60b'], capture_output=True)
diff_text = res.stdout.decode('utf-8', errors='ignore')

# 2. Extract all ASF.request calls in assets/js/admin.js
with open('assets/js/admin.js', 'r', encoding='utf-8', errors='ignore') as f:
    js_content = f.read()

ajax_calls = set(re.findall(r"ASF\.request\(\s*['\"]([^'\"]+)['\"]", js_content))
print(f"Total unique AJAX calls found in admin.js: {len(ajax_calls)}")

# 3. Extract all registered wp_ajax_ actions across PHP files
import glob
php_files = glob.glob('includes/*.php') + ['all-seo-fixer.php']
registered_ajax = set()

for pf in php_files:
    try:
        with open(pf, 'r', encoding='utf-8', errors='ignore') as f:
            c = f.read()
            actions = re.findall(r"wp_ajax_([a-zA-Z0-9_]+)", c)
            for a in actions:
                registered_ajax.add(a)
    except Exception as e:
        print(f"Could not read {pf}: {e}")

print(f"Total unique wp_ajax actions in PHP files: {len(registered_ajax)}")

# Check for any unhandled AJAX calls in JS
unhandled = [a for a in ajax_calls if a not in registered_ajax]
print(f"Unhandled AJAX calls from JS: {unhandled}")

# 4. Check for any syntax errors in JS
node_res = subprocess.run(['node', '-c', 'assets/js/admin.js'], capture_output=True, text=True)
print(f"Node syntax check: returncode={node_res.returncode}, stderr={node_res.stderr.strip()}")

# 5. Check for any PHP syntax errors
for pf in php_files:
    php_res = subprocess.run(['C:\\xampp\\php\\php.exe', '-l', pf], capture_output=True, text=True)
    print(f"PHP syntax {pf}: {php_res.stdout.strip()}")
