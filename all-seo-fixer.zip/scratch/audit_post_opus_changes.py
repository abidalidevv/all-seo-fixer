import os
import sys
import subprocess
import re

sys.stdout.reconfigure(encoding='utf-8')

print("="*70)
print("COMPREHENSIVE POST-OPUS REGRESSION AUDIT (Commit 52af60b -> HEAD)")
print("="*70)

# 1. Check all git diff files
res = subprocess.run(['git', 'diff', '--name-only', '52af60b'], capture_output=True)
files = res.stdout.decode('utf-8', errors='replace').splitlines()
files = [f.strip() for f in files if f.strip()]
print(f"Total modified files since 52af60b: {len(files)}")
for f in files:
    print(f" - {f}")

# 2. Detailed checks on PHP files
php_files = [f for f in files if f.endswith('.php')]
print("\n" + "="*70)
print("PHP SYNTAX & STATIC ANALYSIS")
print("="*70)
for pf in php_files:
    cmd = ['C:\\xampp\\php\\php.exe', '-l', pf]
    c_res = subprocess.run(cmd, capture_output=True, text=True)
    if c_res.returncode != 0:
        print(f"[FAIL] Syntax Error in {pf}: {c_res.stderr.strip()}")
    else:
        print(f"[PASS] {pf} syntax clean.")

# 3. Check for any unresolved merge conflicts, syntax markers, or debug dumps
suspicious_patterns = [
    r'<<<<<<<',
    r'>>>>>>>',
    r'=======',
    r'var_dump\(',
    r'print_r\(',
    r'console\.log\(',
    r'undefined',
    r'alert\(',
]

print("\n" + "="*70)
print("SCANNING FOR CONFLICT MARKERS OR SUSPICIOUS DEBUG ARTIFACTS")
print("="*70)
for f in files:
    if not os.path.exists(f) or os.path.isdir(f):
        continue
    with open(f, 'r', encoding='utf-8', errors='ignore') as fh:
        content = fh.read()
        lines = content.splitlines()
        for idx, line in enumerate(lines, 1):
            if '<<<<<<<' in line or '>>>>>>>' in line:
                print(f"[CRITICAL] Merge conflict marker in {f}:{idx}")
            if 'var_dump(' in line or 'print_r(' in line:
                # check if it's commented out or in real code
                if not line.strip().startswith('//') and not line.strip().startswith('*') and not line.strip().startswith('#'):
                    print(f"[WARN] Debug call in {f}:{idx}: {line.strip()}")

# 4. Check JS syntax
print("\n" + "="*70)
print("JAVASCRIPT STATIC ANALYSIS")
print("="*70)
js_res = subprocess.run(['node', '-c', 'assets/js/admin.js'], capture_output=True, text=True)
if js_res.returncode == 0:
    print("[PASS] assets/js/admin.js compiled with 0 errors.")
else:
    print(f"[FAIL] assets/js/admin.js syntax error: {js_res.stderr.strip()}")

print("\nAUDIT COMPLETED SUCCESSFULLY.")
