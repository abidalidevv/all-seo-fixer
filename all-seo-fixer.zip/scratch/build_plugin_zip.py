import os
import zipfile
import shutil

src_dir = r"c:\Users\Ali\Music\orbix-seo-fixer\all-seo-fixer"
output_zip = r"c:\Users\Ali\Music\orbix-seo-fixer\all-seo-fixer-updated.zip"
legacy_zip = r"c:\Users\Ali\Music\orbix-seo-fixer\all-seo-fixer.zip"

include_dirs = ["admin", "assets", "includes"]
include_files = [
    "all-seo-fixer.php",
    "readme.txt",
    "README.md",
    "DOCUMENTATION.md",
    "documentation.html"
]

print("Packaging plugin into:", output_zip)

with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as zipf:
    for fname in include_files:
        fpath = os.path.join(src_dir, fname)
        if os.path.exists(fpath):
            arcname = os.path.join("all-seo-fixer", fname)
            zipf.write(fpath, arcname)
            print(f"Added file: {arcname}")
            
    for dname in include_dirs:
        dpath = os.path.join(src_dir, dname)
        if os.path.exists(dpath):
            for root, dirs, files in os.walk(dpath):
                for file in files:
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, src_dir)
                    arcname = os.path.join("all-seo-fixer", rel_path)
                    zipf.write(full_path, arcname)

shutil.copyfile(output_zip, legacy_zip)
size_mb = os.path.getsize(output_zip) / (1024 * 1024)
print(f"SUCCESS: Package created ({size_mb:.2f} MB) at both:")
print(f" - {output_zip}")
print(f" - {legacy_zip}")
