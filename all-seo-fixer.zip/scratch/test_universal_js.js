function getCleanBrandJS(domain, siteTitle) {
    var site = (siteTitle || '').trim();
    ['|', '—', '–', ' - ', ':', '•'].forEach(function(d) {
        if (site.indexOf(d) !== -1) {
            site = site.split(d)[0].trim();
        }
    });
    if (!site || site.toLowerCase() === 'wordpress') {
        site = domain.replace(/^www\./i, '').replace(/\.[a-z]{2,6}$/i, '');
        if (site) site = site.charAt(0).toUpperCase() + site.slice(1);
    }
    if (site && site.length > 15) {
        var words = site.split(/\s+/);
        site = words[0];
    }
    return site || 'Brand';
}

function generateSmartTitleJS(pTitle, postType, url, brand) {
    pTitle = (pTitle || 'Page').trim();
    brand = brand || 'Brand';
    var cleaned = pTitle.replace(new RegExp('\\s*([|\\-–—:]\\s*(' + brand + '|Official Site|WordPress)).*$', 'i'), '').trim();
    if (!cleaned) cleaned = pTitle;

    var lower = cleaned.toLowerCase();
    var urlLower = (url || '').toLowerCase();
    var brandSuf = ' | ' + brand;

    var candidates = [];

    if (lower === 'cart' || urlLower.indexOf('/cart') !== -1) {
        candidates = [
            'Your Shopping Cart & Secure Online Checkout' + brandSuf,
            'View Your Shopping Cart & Checkout Online' + brandSuf,
            'Secure Shopping Cart & Order Checkout' + brandSuf
        ];
    } else if (lower === 'checkout' || urlLower.indexOf('/checkout') !== -1) {
        candidates = [
            'Secure Checkout & Fast Order Confirmation' + brandSuf,
            'Complete Your Order & Secure Online Checkout' + brandSuf,
            'Secure Checkout & Quick Order Completion' + brandSuf
        ];
    } else if (lower === 'home' || lower === 'homepage' || urlLower.indexOf('/home') !== -1) {
        candidates = [
            'Welcome to Official Website & Services' + brandSuf,
            'Official Website & Professional Solutions' + brandSuf,
            'Home - Trusted Quality & Professional Care' + brandSuf
        ];
    } else if (lower.indexOf('contact') !== -1) {
        candidates = [
            'Contact Us & Customer Support Helpdesk' + brandSuf,
            'Get in Touch & Dedicated Customer Support' + brandSuf,
            'Contact Our Support Team & Store Location' + brandSuf
        ];
    } else if (lower.indexOf('about') !== -1) {
        candidates = [
            'About Us, Our Company Mission & Expert Team' + brandSuf,
            'About Us & Dedicated Professional Team' + brandSuf,
            'About Our Company, History & Values' + brandSuf
        ];
    } else if (lower === 'services' || lower === 'service' || lower === 'our services' || urlLower.indexOf('/services') !== -1) {
        candidates = [
            'Professional Services & Expert Solutions' + brandSuf,
            'Comprehensive Services & Trusted Solutions' + brandSuf,
            'Expert Services, Certified Quality & Care' + brandSuf
        ];
    } else if (lower.indexOf('repair') !== -1 || lower.indexOf('fix') !== -1 || lower.indexOf('maintenance') !== -1) {
        // Universal repair & technical coverage: screen, battery, touch, button, power, diagnostics
        candidates = [
            cleaned + ' - Complete Repair & Diagnostics' + brandSuf,
            cleaned + ' - Expert Diagnostics & Full Fix' + brandSuf,
            cleaned + ' - Fast, Certified Repair Service' + brandSuf,
            cleaned + ' - Professional Hardware & Tech Fix' + brandSuf,
            cleaned + ' - Trusted Diagnostics & Repair' + brandSuf,
            cleaned + ' - Comprehensive Service & Fix' + brandSuf,
            cleaned + ' - Complete Hardware & System Fix' + brandSuf,
            cleaned + ' - Full Diagnostics & Hardware Fix' + brandSuf,
            cleaned + ' - Expert Service & Diagnostics' + brandSuf,
            cleaned + ' - Professional Certified Repair' + brandSuf,
            cleaned + ' - Complete Multi-Point Repair' + brandSuf,
            cleaned + ' - Fast, Reliable Repair Service' + brandSuf,
            cleaned + ' - Same-Day Certified Repair' + brandSuf,
            cleaned + ' - Expert Hardware Repair & Fix' + brandSuf,
            cleaned + ' - Complete Diagnostics & Fix' + brandSuf,
            cleaned + ' - Trusted Repair & Support' + brandSuf
        ];
    } else if (postType === 'product' || urlLower.indexOf('/product') !== -1 || lower.indexOf('buy') !== -1 || lower.indexOf('shirt') !== -1 || lower.indexOf('shoes') !== -1 || lower.indexOf('bag') !== -1) {
        candidates = [
            'Buy ' + cleaned + ' Online with Warranty' + brandSuf,
            'Original ' + cleaned + ' - Certified Quality & Deals' + brandSuf,
            cleaned + ' - Best Online Deals & Fast Delivery' + brandSuf,
            'Order ' + cleaned + ' Online - Guaranteed Quality' + brandSuf,
            cleaned + ' - Specifications, Price & Warranty' + brandSuf,
            'Buy ' + cleaned + ' Online - Best Price & Warranty' + brandSuf,
            cleaned + ' - Premium Quality & Fast Shipping' + brandSuf
        ];
    } else {
        candidates = [
            cleaned + ' — Complete Overview & Guide' + brandSuf,
            cleaned + ' - Expert Insights & Full Overview' + brandSuf,
            cleaned + ' - Comprehensive Guide & Details' + brandSuf,
            cleaned + ' - Complete Information & Guide' + brandSuf,
            cleaned + ' - Trusted Solutions & Overview' + brandSuf,
            cleaned + ' - Professional Overview & Guide' + brandSuf,
            cleaned + ' - Official Guide & Details' + brandSuf,
            cleaned + ' - Trusted Insights & Guide' + brandSuf
        ];
    }

    for (var i = 0; i < candidates.length; i++) {
        var c = candidates[i];
        if (c.length >= 48 && c.length <= 60) return c;
    }

    var padOptions = [
        ' - Complete Comprehensive Services & Support' + brandSuf,
        ' - Professional Service & Expert Support' + brandSuf,
        ' - Complete Overview & Comprehensive Guide' + brandSuf,
        ' - Professional Solutions & Trusted Care' + brandSuf,
        ' - Expert Diagnostics & Full Solutions' + brandSuf,
        ' - Comprehensive Services & Support' + brandSuf,
        ' - Professional Service & Support' + brandSuf,
        ' - Complete Overview & Guide' + brandSuf,
        ' - Professional Services & Care' + brandSuf,
        ' - Expert Solutions & Overview' + brandSuf,
        ' - Trusted Services & Support' + brandSuf,
        ' - Complete Diagnostic Service' + brandSuf,
        ' - Professional Solutions' + brandSuf,
        ' - Expert Guide & Details' + brandSuf,
        ' - Trusted Quality & Care' + brandSuf,
        ' - Comprehensive Services' + brandSuf,
        ' - Professional Services' + brandSuf,
        ' - Official Specifications' + brandSuf,
        ' - Expert Solutions' + brandSuf,
        ' - Trusted Services' + brandSuf,
        ' - Complete Overview' + brandSuf,
        ' - Complete Guide' + brandSuf,
        ' - Full Overview' + brandSuf,
        ' - Expert Care' + brandSuf,
        ' - Solutions' + brandSuf,
        ' - Overview' + brandSuf,
        ' - Guide' + brandSuf,
        brandSuf
    ];

    for (var j = 0; j < padOptions.length; j++) {
        var cand = cleaned + padOptions[j];
        if (cand.length >= 48 && cand.length <= 60) return cand;
    }

    if ((cleaned + brandSuf).length > 60) {
        var maxBase = 60 - brandSuf.length;
        var sub = cleaned.substring(0, maxBase);
        var lsp = sub.lastIndexOf(' ');
        if (lsp > 15) sub = sub.substring(0, lsp);
        return sub + brandSuf;
    }

    return (cleaned + brandSuf).substring(0, 60);
}

function generateMetaDescFromData(title, snippet, postType, url, brand) {
    title = (title || 'Page').trim();
    brand = brand || 'Brand';
    var cleaned = title.replace(new RegExp('\\s*([|\\-–—:]\\s*(' + brand + '|Official Site|WordPress)).*$', 'i'), '').trim();
    if (!cleaned) cleaned = title;

    var lower = cleaned.toLowerCase();
    var urlLower = (url || '').toLowerCase();

    if (lower === 'cart' || urlLower.indexOf('/cart') !== -1) {
        return ('Review items in your shopping cart at ' + brand + '. Enjoy fast, secure checkout, verified warranty, and dedicated support. Finish your order today!').substring(0, 155);
    }
    if (lower === 'checkout' || urlLower.indexOf('/checkout') !== -1) {
        return ('Complete your secure order at ' + brand + '. Safe encrypted payments, verified guarantees, and fast delivery to your door. Finish your purchase now!').substring(0, 155);
    }
    if (lower === 'services' || lower === 'service' || lower === 'our services' || urlLower.indexOf('/services') !== -1) {
        return ('Explore professional services and trusted solutions at ' + brand + '. Certified specialists, proven quality, and dedicated support. Get in touch today!').substring(0, 155);
    }

    var cand1 = 'Get complete details and professional solutions for ' + cleaned + ' at ' + brand + '. Certified expertise, verified quality, and fast assistance. Contact us today!';
    var cand2 = 'Discover trusted ' + cleaned + ' with ' + brand + '. Certified specialists, high quality standards, reliable results, and full support. Book or order online today!';
    var cand3 = 'Looking for expert ' + cleaned + '? ' + brand + ' provides comprehensive solutions, verified quality, and dedicated customer care. Explore our options now!';

    var metas = [cand1, cand2, cand3];
    for (var i = 0; i < metas.length; i++) {
        if (metas[i].length >= 120 && metas[i].length <= 155) return metas[i];
    }

    if (cand1.length > 155) {
        var sub = cand1.substring(0, 150);
        var lsp = sub.lastIndexOf(' ');
        if (lsp > 100) sub = sub.substring(0, lsp);
        var res = sub.replace(/[.,:;\s-]+$/, '') + '. Contact us today!';
        if (res.length <= 155) return res;
        return sub.replace(/[.,:;\s-]+$/, '') + '.';
    }
    if (cand1.length < 120) {
        return cand1.replace(/[.\s]+$/, '') + '. Contact our expert team today!';
    }
    return cand1;
}

// Test suite across 5 completely different websites
var testSuites = [
    {
        brand: 'eFix',
        domain: 'efix.ae',
        siteTitle: 'eFix Electronics Repair | Mobile Phone & Electronics Repair in Muwaileh Sharjah',
        pages: [
            "Acer Laptop Repair", "Asus Laptop Repair", "Microsoft Surface Pro Repair",
            "Apple iMac Repair", "Apple Macbook Pro Repair", "Apple Macbook Air Repair",
            "Other Tablet Repair", "Android Tablet Repair", "Asus Tablet Repair",
            "Acer Tablet Repair", "Lenovo Tablet Repair", "Other Samsung Device Repair",
            "Samsung A Series Repair", "Samsung J Series Repair", "Samsung Note Series Repair",
            "Samsung Note 8 Repair", "Samsung Note 9 Repair", "Samsung S10 Repair",
            "Samsung S10 Plus Repair", "Samsung Galaxy Note 10 Repair",
            "Samsung Galaxy S20 Repair", "Samsung Galaxy Note 20 Repair",
            "iPhone 8 Repair", "iPhone X Repair"
        ]
    },
    {
        brand: 'HealthClinic',
        domain: 'healthclinic.com',
        siteTitle: 'HealthClinic - Premier Family Medical Care',
        pages: [
            "Pediatric General Consultation", "Cardiology Heart Checkup",
            "Dermatology Skin Treatment", "Orthopedic Joint Care"
        ]
    },
    {
        brand: 'UrbanFashion',
        domain: 'urbanfashion.com',
        siteTitle: 'UrbanFashion Online Apparel Store',
        pages: [
            "Men Slim Fit Cotton Shirt", "Women Classic Trench Coat",
            "Casual Leather Walking Shoes"
        ]
    },
    {
        brand: 'LegalAdvisors',
        domain: 'legaladvisors.org',
        siteTitle: 'LegalAdvisors — Corporate Law Attorneys',
        pages: [
            "Corporate Contract Review", "Intellectual Property Protection",
            "Commercial Lease Negotiations", "Cart", "Checkout", "About Us", "Contact Us"
        ]
    }
];

var allPass = true;
testSuites.forEach(function(suite) {
    var b = getCleanBrandJS(suite.domain, suite.siteTitle);
    console.log("Testing site: " + suite.domain + " | Resolved Brand: " + b);
    suite.pages.forEach(function(p) {
        var t = generateSmartTitleJS(p, 'page', 'https://' + suite.domain + '/' + p.toLowerCase().replace(/\s+/g, '-'), b);
        var m = generateMetaDescFromData(p, '', 'page', 'https://' + suite.domain + '/' + p.toLowerCase().replace(/\s+/g, '-'), b);
        var tOk = t.length >= 48 && t.length <= 60 && t.indexOf('...') === -1;
        var mOk = m.length >= 120 && m.length <= 155;
        if (!tOk || !mOk) allPass = false;
        var stat = (tOk && mOk) ? 'PASS' : 'FAIL';
        console.log(" [" + stat + "] " + (p + "                              ").substring(0, 32) + " | " + t.length + " | " + m.length + " | " + t);
    });
});

if (allPass) {
    console.log("\n>>> 100% OF ALL DIVERSE SITES & NICHES PASSED STRICT 48-60 CHAR & 120-155 CHAR RULES IN JS! <<<");
} else {
    console.log("\n>>> SOME TEST CASES FAILED! <<<");
    process.exit(1);
}
