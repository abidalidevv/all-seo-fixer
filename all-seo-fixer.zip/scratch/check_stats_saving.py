import os
import sys
import re

sys.stdout.reconfigure(encoding='utf-8')

with open('includes/class-asf-handlers.php', 'r', encoding='utf-8') as f:
    content = f.read()

get_opts = set(re.findall(r"get_option\(\s*['\"]([^'\"]+)['\"]", content))
upd_opts = set(re.findall(r"update_option\(\s*['\"]([^'\"]+)['\"]", content))

print('GET OPTIONS:', sorted(list(get_opts)))
print('UPDATE OPTIONS:', sorted(list(upd_opts)))

# Also check wp_postmeta updates
meta_updates = set(re.findall(r"update_post_meta\(\s*[^,]+,\s*['\"]([^'\"]+)['\"]", content))
print('\nUPDATE POST META:', sorted(list(meta_updates)))
