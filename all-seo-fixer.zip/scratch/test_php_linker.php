<?php
function test_auto_link() {
    $content = '<p>Welcome to our center. We provide expert iphone repair services for all models. Our team is certified.</p>
<h2>Why Choose Our iPhone Repair Shop?</h2>
<p>If you need an iphone repair, check our <a href="https://efix.ae/services/">services list</a>. We also fix macbook screen issues.</p>
<div class="iphone repair" data-item="iphone repair"><img src="iphone-repair.jpg" alt="iphone repair" /></div>
<p>Visit us for macbook screen replacement today.</p>';

    $targets = array(
        array(
            'keyword' => 'iphone repair',
            'url'     => 'https://efix.ae/product-category/iphone-repair/',
            'name'    => 'iPhone Repair',
            'type'    => 'product_cat',
        ),
        array(
            'keyword' => 'macbook screen',
            'url'     => 'https://efix.ae/product-category/macbook-screen/',
            'name'    => 'MacBook Screen',
            'type'    => 'product_cat',
        ),
    );

    $tokens = preg_split( '/(<\/?[a-zA-Z0-9]+(?:\s+[^>]*?)?>|<!--[\s\S]*?-->)/i', $content, -1, PREG_SPLIT_DELIM_CAPTURE );
    $forbidden_tags = array( 'a', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'script', 'style', 'button' );
    $in_forbidden   = 0;
    $links_added    = 0;
    $max_links      = 3;
    $used_targets   = array();
    $added_details  = array();
    $new_tokens     = array();

    foreach ( $tokens as $token ) {
        if ( $token === '' ) continue;

        if ( preg_match( '/^<(\/)?([a-zA-Z0-9]+)/', $token, $tm ) ) {
            $is_closing = ! empty( $tm[1] );
            $tag_name   = strtolower( $tm[2] );
            if ( in_array( $tag_name, $forbidden_tags, true ) ) {
                if ( $is_closing ) {
                    $in_forbidden = max( 0, $in_forbidden - 1 );
                } else {
                    $in_forbidden++;
                }
            }
            $new_tokens[] = $token;
        } else {
            if ( $in_forbidden === 0 && $links_added < $max_links ) {
                foreach ( $targets as $target ) {
                    if ( $links_added >= $max_links ) break;
                    $kw = trim( $target['keyword'] );
                    $lower_kw = strtolower( $kw );
                    if ( isset( $used_targets[ $lower_kw ] ) ) continue;

                    $pattern = '/\b(' . preg_quote( $kw, '/' ) . ')\b/i';
                    if ( preg_match( $pattern, $token ) ) {
                        $target_url   = $target['url'];
                        $target_title = $target['name'];

                        $token = preg_replace_callback( $pattern, function( $m ) use ( $target_url, $target_title, $lower_kw, &$links_added, &$used_targets, &$added_details ) {
                            if ( isset( $used_targets[ $lower_kw ] ) ) {
                                return $m[0];
                            }
                            $links_added++;
                            $used_targets[ $lower_kw ] = true;
                            $added_details[] = array(
                                'keyword' => $m[1],
                                'url'     => $target_url,
                                'title'   => $target_title,
                            );
                            return '<a href="' . htmlspecialchars( $target_url ) . '" title="' . htmlspecialchars( $target_title ) . '">' . $m[1] . '</a>';
                        }, $token, 1 );
                    }
                }
            }
            $new_tokens[] = $token;
        }
    }

    echo "Links Added: " . $links_added . "\n";
    echo "Output:\n" . implode( '', $new_tokens ) . "\n";
}

test_auto_link();
