<?php
/**
 * Test internal linking algorithm and On-Page issue resolution
 */

if ( ! defined( 'ABSPATH' ) ) {
    define( 'ABSPATH', __DIR__ . '/' );
}
if ( ! function_exists( 'home_url' ) ) {
    function home_url( $path = '' ) {
        return 'https://efix.ae' . $path;
    }
}
if ( ! function_exists( 'esc_url' ) ) {
    function esc_url( $url ) {
        return htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );
    }
}
if ( ! function_exists( 'esc_attr' ) ) {
    function esc_attr( $text ) {
        return htmlspecialchars( $text, ENT_QUOTES, 'UTF-8' );
    }
}
if ( ! function_exists( 'add_action' ) ) {
    function add_action( $tag, $callback, $priority = 10, $accepted_args = 1 ) {}
}
if ( ! function_exists( 'wp_strip_all_tags' ) ) {
    function wp_strip_all_tags( $string, $remove_breaks = false ) {
        return strip_tags( $string );
    }
}
if ( ! function_exists( 'strip_shortcodes' ) ) {
    function strip_shortcodes( $content ) {
        return $content;
    }
}

require_once __DIR__ . '/../includes/class-asf-handlers.php';

echo "=== TEST 1: Internal Linking Safe Replacements ===\n";

$sample_html = '
<div class="product-description">
    <p>We are the leading center for iphone repair and screen replacement services in Sharjah.</p>
    <h2>Expert iPhone Repair Technicians</h2>
    <p>Get in touch for macbook screen or visit our store. If you already checked our <a href="https://efix.ae/iphone-repair/">iphone repair page</a>, you know our prices are the best.</p>
    <div class="iphone repair item"><img src="iphone-repair.jpg" alt="iphone repair" /></div>
    <p>Fast turnaround for all your macbook screen fixes.</p>
</div>
';

$targets = array(
    array(
        'keyword' => 'iphone repair',
        'url'     => 'https://efix.ae/product-category/iphone-repair/',
        'name'    => 'iPhone Repair',
        'type'    => 'product_cat',
    ),
    array(
        'keyword' => 'macbook screen',
        'url'     => 'https://efix.ae/product-category/macbook-screen/',
        'name'    => 'MacBook Screen',
        'type'    => 'product_cat',
    ),
);

$res = ASF_InternalLinks::auto_link_content( $sample_html, $targets, 'https://efix.ae/product/used-iphone-12-pro-max/', 3 );

echo "Links added: " . $res['links_added'] . "\n";
echo "Added details:\n";
foreach ( $res['added_links'] as $al ) {
    echo " - Keyword: '{$al['keyword']}' -> {$al['url']} ({$al['title']})\n";
}

// Verify no nested <a>
$has_nested_a = preg_match( '/<a[^>]*>[^<]*<a/i', $res['content'] );
echo "Nested <a> tags present: " . ( $has_nested_a ? "FAIL (Yes)" : "PASS (No)" ) . "\n";

// Verify heading was NOT altered into a link
$heading_has_link = preg_match( '/<h2[^>]*>.*?<a/i', $res['content'] );
echo "Heading has internal link: " . ( $heading_has_link ? "FAIL (Yes)" : "PASS (No)" ) . "\n";

// Verify image alt and class attribute were NOT altered
$attr_intact = ( strpos( $res['content'], 'alt="iphone repair"' ) !== false && strpos( $res['content'], 'class="iphone repair item"' ) !== false );
echo "Tag attributes intact: " . ( $attr_intact ? "PASS" : "FAIL" ) . "\n";

echo "\n=== TEST 2: Self-Linking Prevention ===\n";
$self_res = ASF_InternalLinks::auto_link_content(
    '<p>Find out more on iphone repair today.</p>',
    $targets,
    'https://efix.ae/product-category/iphone-repair/', // same url!
    3
);
echo "Self-links added: " . $self_res['links_added'] . " (Expected: 0)\n";

echo "\n=== TEST 3: Counting Internal Links ===\n";
$cnt = ASF_InternalLinks::count_internal_links( $res['content'] );
echo "Total internal links detected in output: {$cnt} (Expected: at least 3, including the existing link)\n";

echo "\nALL AUTOMATED TESTS COMPLETED SUCCESSFULLY!\n";
